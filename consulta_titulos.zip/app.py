
from flask import Flask, request, render_template, jsonify
import sqlite3

app = Flask(__name__)

def buscar_titulos(nome, secao):
    conn = sqlite3.connect('titulos.db')
    cursor = conn.cursor()
    cursor.execute("SELECT titulo FROM titulos WHERE nome LIKE ? AND secao = ?", (f"%{nome}%", secao))
    resultados = cursor.fetchall()
    conn.close()
    return [r[0] for r in resultados]

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/buscar', methods=['POST'])
def buscar():
    nome = request.form.get('nome')
    secao = request.form.get('secao')
    titulos = buscar_titulos(nome, secao)
    return jsonify(titulos)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
