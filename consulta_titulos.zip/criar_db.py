
import sqlite3
import pandas as pd

# Carrega CSV
df = pd.read_csv('data/titulos.csv')

# Cria DB e tabela
conn = sqlite3.connect('titulos.db')
df.to_sql('titulos', conn, if_exists='replace', index=False)
conn.close()

print("Banco de dados criado com sucesso.")
